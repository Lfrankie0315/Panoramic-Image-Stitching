close all
clear
clc
run('/Users/frankie/Documents/MATLAB/Visual Computing/project 1/vlfeat-0.9.21/toolbox/vl_setup')
I1 = imresize(imread('/Users/frankie/Desktop/IMG_6608.jpeg'),[640,480]);
I2 = imresize(imread('/Users/frankie/Desktop/IMG_6609.jpeg'),[640,480]);
I3 = imresize(imread('/Users/frankie/Desktop/IMG_6610.jpeg'),[640,480]);
I4 = imresize(imread('/Users/frankie/Desktop/IMG_6611.jpeg'),[640,480]);
I5 = imresize(imread('/Users/frankie/Desktop/IMG_6612.jpeg'),[640,480]);
left_pano = panorama_stitch(I3,I2,I1);
right_pano = panorama_stitch(I3,I4,I5);
figure(1)
imshow(uint8(left_pano));
figure(2)
imshow(uint8(right_pano));
%%
[r1,c1,~] = size(left_pano);
[r2,c2,~] = size(right_pano);
[r3,c3,~] = size(I3);
pano_matrix_l = zeros(max(r1,r2),c1+c2-c3,3);
pano_matrix_r = zeros(max(r1,r2),c1+c2-c3,3);
pano_matrix_l(end-r1+1:end,1:c1,:) = left_pano;
pano_matrix_r(end-r2-130:end-131,end-c2+1:end,:) = right_pano;
overlap_area = pano_matrix_l.*pano_matrix_r;
overlap_area = 0.5*sign(overlap_area);
for i = 1 : size(overlap_area,1)
    for j = 1 : size(overlap_area,2)
           if overlap_area(i,j,1) == 0
               overlap_area(i,j,1) = 1;
           end
    end
end 
overlap_area(:,:,2) = overlap_area(:,:,1);
overlap_area(:,:,3) = overlap_area(:,:,1);
final_pano = overlap_area.*(pano_matrix_l+pano_matrix_r);
figure(3)
imshow(uint8(final_pano));
function pano_img = panorama_stitch(I3,I2,I1)
Cleft = cell(1,4);
%Cright = cell(1,4);
Cleft(1:4) = {I3,I2,I1,I1};% store each image
%Cright(1:4) = {I3,I4,I5,I5};
Cleft_homo = cell(1,3);%record each homography
%Cright_homo = cell(1,3);
Cleft_homop = cell(1,3);
%Cright_homop = cell(1,3); %record each p of homography
Cleft_image = cell(1,3);%record each already transferred image
%Cright_image = cell(1,3);
%% left transfer 2 and 1 to 3
transfer_image = cell2mat(Cleft(2));% the image we need to transfer I2
steady_image = cell2mat(Cleft(1));% the I3
for lambda  = 1 : 2
%     figure((lambda-1)*3+1)
%     imshow(uint8(transfer_image));
%     title('transfer image');
%     figure((lambda-1)*3+2)
%     imshow(uint8(steady_image));
%     title('I3');
    I1_gray = single(rgb2gray(transfer_image));
    I2_gray = single(rgb2gray(steady_image));
    [f1,d1] = vl_sift(I1_gray);
    [f2,d2] = vl_sift(I2_gray);
    %% sift match
    match_idx = zeros(1,size(d1,2));%record the match keypoint as idx in I2
    d1 = double(d1);
    d2 = double(d2);
    for i = 1 : size(d1,2)
        dis = 100000;
        idx = 1;
        for j = 1 : size(d2,2)
            tmp = norm(d1(:,i)-d2(:,j));
            if tmp < dis
                dis = tmp;
                idx = j;
            end
            match_idx(i) = idx;
        end
    end   
% RANSAC
    sigma = 2; %ransac threshold
    inlier_idx = zeros(1,size(f1,2)); %record the idx of inliers
    inlier_num = 0; %record the number of inliers
    max_t = 0; %in which iteration can we the max number of inlier
    for t = 1 : 30000
        perm = randperm(size(f1,2),5);%choose 5 random points
        initial_point = f1(1:2,perm);
        rela_point = f2(1:2,match_idx(perm));
        homoA = zeros(10,9);
        for i = 1 : 5
            x = initial_point(1,i);
            y = initial_point(2,i);
            x_a = rela_point(1,i);
            y_a = rela_point(2,i);
            homoA(2*i-1,:) = [x,y,1,zeros(1,3),-x*x_a,-y*x_a,-x_a];
            homoA(2*i,:) = [zeros(1,3),x,y,1,-x*y_a,-y*y_a,-y_a];
        end
        [~,~,V] = svd(homoA);
        p = V(:,end);
        point_trans = zeros(2,size(f1,2));
        for i = 1 : size(f1,2)
            x = f1(1,i);
            y = f1(2,i);
            point_trans(1,i) = (p(1)*x+p(2)*y+p(3))/(p(7)*x+p(8)*y+p(9));
            point_trans(2,i) = (p(4)*x+p(5)*y+p(6))/(p(7)*x+p(8)*y+p(9));
        end
        inlier_tmp = 0;
        inlier_idx_tmp = zeros(1,size(f1,2));
        for i = 1 : size(f1,2)
            tmp = norm(point_trans(:,i)-f2(1:2,match_idx(i)));
            if tmp <= sigma
                inlier_tmp = inlier_tmp + 1;
                inlier_idx_tmp(i) = 1;%record the idx of point which is inlier
            end
        end
        if inlier_tmp > inlier_num
            inlier_num = inlier_tmp;
            max_t = t;%record the interation now if we find a new homo which have more inliers
            inlier_idx=inlier_idx_tmp;
        end
    end
    in_idx = find(inlier_idx);
    H = zeros(2*inlier_num,9);
    for i = 1 : inlier_num
        x = f1(1,in_idx(i));
        y = f1(2,in_idx(i));
        x_a = f2(1,match_idx(in_idx(i)));
        y_a = f2(2,match_idx(in_idx(i)));
        H(2*i-1,:) = [x,y,1,zeros(1,3),-x*x_a,-y*x_a,-x_a];
        H(2*i,:) = [zeros(1,3),x,y,1,-x*y_a,-y*y_a,-y_a];
    end
    [~,~,V1] = svd(H);
    p1 = V1(:,end);
    %p1 = p1/norm(p1);
    H1 = reshape(p1,3,3);
    tform1 = projective2d(H1);
    h1_trans = imwarp(transfer_image,tform1);
    Cleft_homo{lambda} = H1;
    %C_homop{lambda} = p1;
    Cleft_image{lambda} = h1_trans;
%     figure((lambda-1)*3+3)
%     imshow(h1_trans)
%     title('transferred image')
    transfer_image = cell2mat(Cleft(lambda+2));%I1
    steady_image = cell2mat(Cleft(2));
end
Cleft_image{2} = imwarp(I1,projective2d(cell2mat(Cleft_homo(2))*cell2mat(Cleft_homo(1))));
left_image = cell(1,2);
%%  image stiching
left_homo1= cell2mat(Cleft_homo(1));
left_homo2 = cell2mat(Cleft_homo(2))*cell2mat(Cleft_homo(1));
Cleft_homop{1} = reshape(left_homo1,9,1);
Cleft_homop{2} = reshape(left_homo2,9,1);
%C_homop{3} = reshape(big_homo3,9,1);
transfer_image1 = cell2mat(Cleft(2));%the image we will transfer (I2)
h1_trans1 = cell2mat(Cleft_image(1));% already transferred I2
steady_image1 = cell2mat(Cleft(1));%I3
p1 = cell2mat(Cleft_homop(1));
left_coor = cell(2,3);
for eta = 1 : lambda
    [r1,c1,~] = size(transfer_image1);
    [r2,c2,~] = size(h1_trans1);
    [r3,c3,~] = size(steady_image1);
    [gridx1,gridy1] = meshgrid(1:c1,1:r1);
    [gridx3,gridy3] = meshgrid(1:c3,1:r3);
    gridx1_t = round((gridx1*p1(1)+gridy1*p1(2)+p1(3))./(gridx1*p1(7)+gridy1*p1(8)+p1(9)));
    gridy1_t = round((gridx1*p1(4)+gridy1*p1(5)+p1(6))./(gridx1*p1(7)+gridy1*p1(8)+p1(9)));
    left_coor{1,eta} = gridx1_t;
    left_coor{2,eta} = gridy1_t;
    transfer_image1 = cell2mat(Cleft(eta+2));%I1
    h1_trans1 = cell2mat(Cleft_image(eta+1));%already transferred I1
    p1 = cell2mat(Cleft_homop(eta+1));
    %steady_image = cell2mat(Clest_image(eta));
end  
gridx1 = cell2mat(left_coor(1,1));
gridy1 = cell2mat(left_coor(2,1));
gridx2 = cell2mat(left_coor(1,2));
gridy2 = cell2mat(left_coor(2,2));
%left_coor(1:2,3) = [gridx3,gridy3]';
lminc1 = min(min(gridx1));
lminr1 = min(min(gridy1));
lminc2 = min(min(gridx2));
lminr2 = min(min(gridy2));
lminc = min(lminc1,lminc2);
lminr = min(lminr1,lminr2);
if lminc <= 0
    gridx1 = gridx1 + (abs(lminc) + 1)*ones(size(gridx1,1),size(gridx1,2));
    gridx2 = gridx2 + (abs(lminc) + 1)*ones(size(gridx2,1),size(gridx2,2));
    gridx3 = gridx3 + (abs(lminc) + 1)*ones(size(gridx3,1),size(gridx3,2));
end
if lminr <= 0
    gridy1 = gridy1 + (abs(lminr) + 1)*ones(size(gridy1,1),size(gridy1,2));
    gridy2 = gridy2 + (abs(lminr) + 1)*ones(size(gridy2,1),size(gridy2,2));
    gridy3 = gridy3 + (abs(lminr) + 1)*ones(size(gridy3,1),size(gridy3,2));
end
lminc1 = min(min(gridx1));
lminr1 = min(min(gridy1));
lminc2 = min(min(gridx2));
lminr2 = min(min(gridy2));
lminc = min(lminc1,lminc2);
lminr = min(lminr1,lminr2);
lmaxc1 = max(max(gridx1));
lmaxr1 = max(max(gridy1));
lmaxc2 = max(max(gridx2));
lmaxr2 = max(max(gridy2));
lmaxc3 = max(max(gridx3));
lmaxr3 = max(max(gridy3));
lmaxc = max([lmaxc1,lmaxc2,lmaxc3]);
lmaxr = max([lmaxr1,lmaxr2,lmaxr3]);
coor_matrix1 = zeros(lmaxr+10,lmaxc+10,3);
coor_matrix2 = zeros(lmaxr+10,lmaxc+10,3);
coor_matrix3 = zeros(lmaxr+10,lmaxc+10,3);
% ���￪ʼ�����Ļ���Ӹ��������ͼ��.
coor_matrix1(lminr2:lminr2+size(cell2mat(Cleft_image(2)),1)-1,lminc2:lminc2+size(cell2mat(Cleft_image(2)),2)-1,:) = cell2mat(Cleft_image(2));
coor_matrix2(lminr1:lminr1+size(cell2mat(Cleft_image(1)),1)-1,lminc1:lminc1+size(cell2mat(Cleft_image(1)),2)-1,:) = cell2mat(Cleft_image(1));
coor_matrix3(gridy3(1,1):gridy3(1,1)+size(I3,1)-1,gridx3(1,1):gridx3+size(I3,2)-1,:) = I3;
overlap_area1 = 0.5*sign(coor_matrix1.*coor_matrix2);
for i = 1 : size(overlap_area1,1)
    for j = 1 : size(overlap_area1,2)
           if overlap_area1(i,j,1) == 0
               overlap_area1(i,j,1) = 1;
           end
    end
end 
overlap_area1(:,:,2) = overlap_area1(:,:,1);
overlap_area1(:,:,3) = overlap_area1(:,:,1);
overlap_area2 = 0.5*sign(coor_matrix2.*coor_matrix3);
for i = 1 : size(overlap_area2,1)
    for j = 1 : size(overlap_area2,2)
           if overlap_area2(i,j,1) == 0
               overlap_area2(i,j,1) = 1;
           end
    end
end 
overlap_area2(:,:,2) = overlap_area2(:,:,1);
overlap_area2(:,:,3) = overlap_area2(:,:,1);
coor_matrix1_2 = overlap_area1.*(coor_matrix1 + coor_matrix2);%ͼ2ƴͼ1
coor_matrix2_3 = overlap_area2.*(coor_matrix2 + coor_matrix3);%ͼ2ƴͼ3

overlap_area3 = 0.5*sign(coor_matrix2_3.*coor_matrix1_2);
for i = 1 : size(overlap_area3,1)
    for j = 1 : size(overlap_area3,2)
           if overlap_area3(i,j,1) == 0
               overlap_area3(i,j,1) = 1;
           end
    end
end 
overlap_area3(:,:,2) = overlap_area3(:,:,1);
overlap_area3(:,:,3) = overlap_area3(:,:,1);
pano_matrix = overlap_area3.*(coor_matrix2_3+coor_matrix1_2);
pano_img = pano_matrix;
end