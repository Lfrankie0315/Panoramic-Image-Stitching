clc;
clear;
%% % image transfer
I1 = imread('/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework/assg1/im01.jpg');
I2 = imread('/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework/assg1/im02.jpg');
figure(1)
imshow(I1);
[x1,y1] = getpts;
title('please choose 4 points and ''press enter''');
figure(2)
imshow(I2);
title('please choose 4 points and ''press enter''');
[x2,y2] = getpts;
k = length(x1);
A1 = zeros(8,9);
A2 = zeros(8,9);
for i = 1 : k
    x = x1(i);
    y = y1(i);
    x_a = x2(i);
    y_a = y2(i);
    A1(2*i-1,:) = [x,y,1,zeros(1,3),-x_a*x,-x_a*y,-x_a];
    A1(2*i,:) = [zeros(1,3),x,y,1,-x*y_a,-y*y_a,-y_a];
    A2(2*i-1,:) = [x_a,y_a,1,zeros(1,3),-x_a*x,-x*y_a,-x];
    A2(2*i,:) = [zeros(1,3),x_a,y_a,1,-x_a*y,-y*y_a,-y];
    %temp = [x1(i),y1(i),1,0,0,0,-x2(i)*x1(i),-x2(i)*y1(i),-x2(i);0,0,0,x1(i),y1(i),1,-x1(i)*y2(i),-y1(i)*y2(i),-y2(i)];
    %A((i-1)*2+1:(i*2),:) = temp;
end
[~,~,V1] = svd(A1);
[~,~,V2] = svd(A2);
p1 = V1(:,end);
p1 = p1/norm(p1);
H1 = reshape(p1,3,3);
p2 = V2(:,end);
p2 = p2/norm(p2);
H2 = reshape(p2,3,3);
tform1 = projective2d(H1);
tform2 = projective2d(H2);
h1_trans = imwarp(I1,tform1);
h2_trans = imwarp(I2,tform2);
figure(3)
title('h1 to h2')
imshow(h1_trans);
figure(4)
title('h2 to h1')
imshow(h2_trans)
%% image stiching
[r1,c1,~] = size(I2);
[r2,c2,~] = size(h2_trans);
[gridx1,gridy1] = meshgrid(1:c1,1:r1);
%[gridx2,gridy2] = meshgrid(1:y2,1:x2);
gridx1_t = round((gridx1*p2(1)+gridy1*p2(2)+p2(3))./(gridx1*p2(7)+gridy1*p2(8)+p2(9)));
gridy1_t = round((gridx1*p2(4)+gridy1*p2(5)+p2(6))./(gridx1*p2(7)+gridy1*p2(8)+p2(9)));
%minx = min(min(gridx1));
minc_t1 = min(min(gridx1_t));
%min_c = int32(min(1,minc_t));
minr_t1 = min(min(gridy1_t));
%min_r = int32(min(1,minr_t));
%%max_c = int32(max(c1,maxc_t));
%maxr_t = max(max(gridy1_t));
%max_r = int32(max(r1,maxr_t));
if minc_t1 <= 0
    gridx1 = gridx1+ones(r1,c1).*(abs(minc_t1)+1);
    gridx1_t = gridx1_t+ones(r1,c1).*(abs(minc_t1)+1);
end    
if minr_t1 <=0
   gridy1 = gridy1+ones(r1,c1).*(1+abs(minr_t1));
   gridy1_t = gridy1_t+ones(r1,c1).*(1+abs(minr_t1));  
end
%minx = min(min(gridx1));
minc_t = min(min(gridx1_t));
min_c = round(min(1,minc_t));
minr_t = min(min(gridy1_t));
min_r = round(min(1,minr_t));
maxc_t = max(max(gridx1_t));
max_c = round(max(max(max(gridx1)),maxc_t));
maxr_t = max(max(gridy1_t));
max_r = round(max(max(max(gridy1)),maxr_t));
coor_matrix1 = zeros(max_r+10,max_c+10,3);
coor_matrix1(gridy1(1,1):gridy1(1,1)+size(I1,1)-1,gridx1(1,1):gridx1(1,1)+size(I1,2)-1,:) = I1;
coor_matrix2 = zeros(max_r+10,max_c+10,3);
coor_matrix2(minr_t:minr_t+r2-1,minc_t:minc_t+c2-1,:) = h2_trans;
overlap_area = coor_matrix1.*coor_matrix2;
overlap_area = 0.5*sign(overlap_area);
for i = 1 : size(overlap_area,1)
    for j = 1 : size(overlap_area,2)
           if overlap_area(i,j,1) == 0
               overlap_area(i,j,1) = 1;
           end
    end
end 
overlap_area(:,:,2) = overlap_area(:,:,1);
overlap_area(:,:,3) = overlap_area(:,:,1);
% wid = c1+c2-(max_c-min_c+1);%overlap_width
% len = r1+r2-(max_r-min_r+1);%overlap_height
% if max(max(gridy1))<= maxr_t
%     %overlap  ��h1�����Ͻ�
%     idx_ol = [gridy1(1,end),gridx1(1,end)-wid+1;gridy1(1,end)+len,gridx1(1,end)];
% else
%     %ovelap ��h1�����½�
%     idx_ol = [minr_t,minc_t;gridy1(end,end),gridx1(end,end)];
% end   
%coor_matrix = coor_matrix1+coor_matrix2;
%coor_matrix(idx_ol(1,1):idx_ol(1,1)+len,idx_ol(1,2):idx_ol(1,2)+wid,:) = coor_matrix(idx_ol(1,1):idx_ol(1,1)+len,idx_ol(1,2):idx_ol(1,2)+wid,:)*0.5;
coor_matrix = coor_matrix1+coor_matrix2;
coor_matrix = coor_matrix.*overlap_area;
figure(5)
imshow(uint8(coor_matrix))
%rectangle('Position',[idx_ol(1,1),idx_ol(1,2),wid,len])