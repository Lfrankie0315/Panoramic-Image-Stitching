clc;
clear;
I1 = imread('/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework/assg1/h1.jpg');
I2 = imread('/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework/assg1/h2.jpg');
figure(1)
imshow(I1);
[x1,y1] = getpts;
title('please choose 4 points and ''press enter''');
figure(2)
imshow(I2);
title('please choose 4 points and ''press enter''');
[x2,y2] = getpts;
A1 = zeros(8,9);
A2 = zeros(8,9);
for i = 1 : 4
    x = x1(i);
    y = y1(i);
    x_a = x2(i);
    y_a = y2(i);
    A1(2*i-1,:) = [x,y,1,zeros(1,3),-x_a*x,-x_a*y,-x_a];
    A1(2*i,:) = [zeros(1,3),x,y,1,-x*y_a,-y*y_a,-y_a];
    A2(2*i-1,:) = [x_a,y_a,1,zeros(1,3),-x_a*x,-x*y_a,-x];
    A2(2*i,:) = [zeros(1,3),x_a,y_a,1,-x_a*y,-y*y_a,-y];
    %temp = [x1(i),y1(i),1,0,0,0,-x2(i)*x1(i),-x2(i)*y1(i),-x2(i);0,0,0,x1(i),y1(i),1,-x1(i)*y2(i),-y1(i)*y2(i),-y2(i)];
    %A((i-1)*2+1:(i*2),:) = temp;
end
[~,~,V1] = svd(A1);
[~,~,V2] = svd(A2);
H1 = V1(:,end);
H1 = H1/norm(H1);
H1 = reshape(H1,3,3);
H2 = V2(:,end);
H2 = H2/norm(H2);
H2 = reshape(H2,3,3);
tform1 = projective2d(H1);
tform2 = projective2d(H2);
h1_trans = imwarp(I1,tform1);
h2_trans = imwarp(I2,tform2);
figure(3)
title('h1 to h2')
imshow(h1_trans);
figure(4)
title('h2 to h1')
imshow(h2_trans)

    
