close all
clear
clc
run('/Users/frankie/Documents/MATLAB/Visual Computing/project 1/vlfeat-0.9.21/toolbox/vl_setup')
I1 = imread('/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework/assg1/im01.jpg');
I2 = imread('/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework/assg1/im02.jpg');
figure(1)
imshow(I1);
title('original im01');
figure(2)
imshow(I2);
title('original im02');
I1_gray = single(rgb2gray(I1));
I2_gray = single(rgb2gray(I2));
[f1,d1] = vl_sift(I1_gray);
[f2,d2] = vl_sift(I2_gray);
%% %sift match
match_idx = zeros(1,size(d1,2));%record the match keypoint as idx in I2
d1 = double(d1);
d2 = double(d2);
for i = 1 : size(d1,2)
    dis = 100000;
    idx = 1;
    for j = 1 : size(d2,2)
        tmp = norm(d1(:,i)-d2(:,j));
        if tmp < dis
            dis = tmp;
            idx = j;
        end
    match_idx(i) = idx;
    end
end    
match_img = zeros(size(I1,1),size(I1,2)+size(I2,2),3);
match_img(:,1:size(I1,2),:) = I1;
match_img(:,size(I1,2)+1:end,:) = I2;
g2 = f2;
g2(1,:) = f2(1,:) + size(I1,2)*ones(1,size(f2,2));
figure(3)
imshow(uint8(match_img))
hold on
for i = 1 : size(f1,2)
    plot([f1(1,i),g2(1,match_idx(i))],[f1(2,i),g2(2,match_idx(i))])
end    
hold off       
%% RANSAC 
sigma = 2; %ransac threshold
inlier_idx = zeros(1,size(f1,2)); %record the idx of inliers
inlier_num = 0; %record the number of inliers
max_t = 0; %in which iteration can we the max number of inlier
for t = 1 : 70000
    perm = randperm(size(f1,2),5);%choose 5 random points 
    initial_point = f1(1:2,perm);
    rela_point = f2(1:2,match_idx(perm));
    homoA = zeros(10,9);
    for i = 1 : 5
        x = initial_point(1,i);
        y = initial_point(2,i);
        x_a = rela_point(1,i);
        y_a = rela_point(2,i);
        homoA(2*i-1,:) = [x,y,1,zeros(1,3),-x*x_a,-y*x_a,-x_a];
        homoA(2*i,:) = [zeros(1,3),x,y,1,-x*y_a,-y*y_a,-y_a];
    end
    [~,~,V] = svd(homoA);
    p = V(:,end);
    point_trans = zeros(2,size(f1,2));
    for i = 1 : size(f1,2)
        x = f1(1,i);
        y = f1(2,i);
        point_trans(1,i) = (p(1)*x+p(2)*y+p(3))/(p(7)*x+p(8)*y+p(9));
        point_trans(2,i) = (p(4)*x+p(5)*y+p(6))/(p(7)*x+p(8)*y+p(9));
    end
    inlier_tmp = 0;
    inlier_idx_tmp = zeros(1,size(f1,2));
    for i = 1 : size(f1,2)
        tmp = norm(point_trans(:,i)-f2(1:2,match_idx(i)));
        if tmp <= sigma
            inlier_tmp = inlier_tmp + 1;
            inlier_idx_tmp(i) = 1;%record the idx of point which is inlier
        end    
    end    
    if inlier_tmp > inlier_num
        inlier_num = inlier_tmp;
        max_t = t;%record the interation now if we find a new homo which have more inliers
        inlier_idx=inlier_idx_tmp;
    end
end   
in_idx = find(inlier_idx);
H = zeros(2*inlier_num,9);
for i = 1 : inlier_num
    x = f1(1,in_idx(i));
    y = f1(2,in_idx(i));
    x_a = f2(1,match_idx(in_idx(i)));
    y_a = f2(2,match_idx(in_idx(i)));
    H(2*i-1,:) = [x,y,1,zeros(1,3),-x*x_a,-y*x_a,-x_a];
    H(2*i,:) = [zeros(1,3),x,y,1,-x*y_a,-y*y_a,-y_a];
end
[~,~,V1] = svd(H);
p1 = V1(:,end);
p1 = p1/norm(p1);
H1 = reshape(p1,3,3);
tform1 = projective2d(H1);
h1_trans = imwarp(I1,tform1);
figure(4)
imshow(h1_trans)
title('h1 to h2')
%% inlier sift match
figure(5)
imshow(uint8(match_img))
hold on
for i = 1 : inlier_num
    plot([f1(1,in_idx(i)),g2(1,match_idx(in_idx(i)))],[f1(2,in_idx(i)),g2(2,match_idx(in_idx(i)))])
end   
hold off
%% image stiching
[r1,c1,~] = size(I1);
[r2,c2,~] = size(h1_trans);
[gridx1,gridy1] = meshgrid(1:c1,1:r1);
gridx1_t = round((gridx1*p1(1)+gridy1*p1(2)+p1(3))./(gridx1*p1(7)+gridy1*p1(8)+p1(9)));
gridy1_t = round((gridx1*p1(4)+gridy1*p1(5)+p1(6))./(gridx1*p1(7)+gridy1*p1(8)+p1(9)));
minc_t1 = min(min(gridx1_t));
minr_t1 = min(min(gridy1_t));
if minc_t1 <= 0
    gridx1 = gridx1+ones(r1,c1).*(abs(minc_t1)+1);
    gridx1_t = gridx1_t+ones(r1,c1).*(abs(minc_t1)+1);
end    
if minr_t1 <=0
   gridy1 = gridy1+ones(r1,c1).*(1+abs(minr_t1));
   gridy1_t = gridy1_t+ones(r1,c1).*(1+abs(minr_t1));  
end
minc_t = min(min(gridx1_t));
min_c = round(min(1,minc_t));
minr_t = min(min(gridy1_t));
min_r = round(min(1,minr_t));
maxc_t = max(max(gridx1_t));
max_c = round(max(max(max(gridx1)),maxc_t));
maxr_t = max(max(gridy1_t));
max_r = round(max(max(max(gridy1)),maxr_t));
coor_matrix1 = zeros(max_r+10,max_c+10,3);
coor_matrix1(gridy1(1,1):gridy1(1,1)+size(I2,1)-1,gridx1(1,1):gridx1(1,1)+size(I2,2)-1,:) = I2;
coor_matrix2 = zeros(max_r+10,max_c+10,3);
coor_matrix2(minr_t:minr_t+r2-1,minc_t:minc_t+c2-1,:) = h1_trans;
overlap_area =  coor_matrix1.*coor_matrix2;
overlap_area = 0.5*sign(overlap_area);
for i = 1 : size(overlap_area,1)
    for j = 1 : size(overlap_area,2)
           if overlap_area(i,j,1) == 0
               overlap_area(i,j,1) = 1;
           end
    end
end 
overlap_area(:,:,2) = overlap_area(:,:,1);
overlap_area(:,:,3) = overlap_area(:,:,1);
coor_matrix = coor_matrix1+coor_matrix2;
coor_matrix = coor_matrix.*overlap_area;
figure(6)
imshow(uint8(coor_matrix))