clear
clc
run('/Users/frankie/Documents/MATLAB/Visual Computing/project 1/vlfeat-0.9.21/toolbox/vl_setup')
I1 = imread('/Users/frankie/Documents/MATLAB/Visual Computing/project 1/assg1/im01.jpg');
image(I1)
%I2 = imread('/Users/frankie/Documents/MATLAB/Visual Computing/project 1/assg1/im02.jpg');
%I = vl_impattern('/Users/frankie/Documents/MATLAB/Visual Computing/project 1/assg1/im01.jpg');
%image(I)
I1 = single(rgb2gray(I1));
%I2 = single(rgb2gray(I2));
[f,d] = vl_sift(I1);
%[f2,d2] = vl_sift(I2);
perm = randperm(size(f,2));
sel = perm(1:100);
%h1 = vl_plotframe(f(:,sel);
%se
h2 = vl_plotsiftdescriptor(d(:,sel),f(:,sel));
set(h2,'color','y');

