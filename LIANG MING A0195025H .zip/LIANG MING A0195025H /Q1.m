clc
clear
kernel_width = 31;
kernel_height = 31;%select the size of kernel
kernel_number = 2;%select the type of kernel
haar_like_number = 2; %choose five size
raw_image = double(rgb2gray(imread('Lenna.png')));
[a,b] = size(raw_image);
test_m = zeros(3*a,3*b);
for i = 0 :2
    for j = 0 : 2
        test_m(i*a+1:(i+1)*a,j*b+1:(j+1)*b) = raw_image;
    end
end 
image = test_m;
real_idx = [a+1,b+1;2*a,2*b];% the top-left and bottom-right idx of original image
d = kernel_width;%size of the kernel
c = kernel_height;
if kernel_number == 1 || kernel_number ==2
    if kernel_number == 1 % Sobel
        Sobel_x = [1,0,-1;2,0,-2,;1,0,-1];
        Sobel_y = [1,2,1;0,0,0;-1,-2,-1];
        kernel_matrix = Sobel_x;
   
    elseif kernel_number == 2 % Gaussiam
        sigma = 20; 
        %change sigma here
        idx_x = 0;
        idx_y = 0;
        kernel_matrix = zeros(c,d);
        for x = -(c-1)/2:(c-1)/2
            idx_x = idx_x+1;
            for y = -(d-1)/2:(d-1)/2
                idx_y = idx_y+1;
                kernel_matrix(idx_x,idx_y) = 1/(2*pi*sigma^2)*exp(-(x^2+y^2)/(2*sigma^2));
                if idx_y == d
                   idx_y = 0;
                end   
            end
        end  
        kernel_matrix = kernel_matrix/sum(kernel_matrix(:));
        %kernel_matrix = fspecial('gaussian',7,7);
    %square_kernel convolution 
    %st_idx_x= a+1-(c-1)/2;
    %st_idx_y = b+1-(d-1)/2;
    end
    %convulution
    for i = a+1:2*a
        for j = b+1:2*b
            count = 0;
            r = 0;
            s = 0;
            % ������
            for p = i-(c-1)/2:(i-(c-1)/2+(c-1))
                r = r + 1;
                for q = j-(d-1)/2:(j-(d-1)/2+(d-1))
                    s = s + 1;
                    tem = test_m(p,q)*kernel_matrix(r,s);
                    count = count + tem;
                    if s == d
                        s = 0;
                    end    
                end
            end    
            image(i,j) = count;
        end
    end
else
    kernel_matrix = ones(c,d);
    if haar_like_number == 1
        kernel_matrix(1:c/2,:) = -1;
        %kernel_matrix((c/2-1):c,:) = 1;
    elseif haar_like_number == 2
        kernel_matrix(:,1:d/2) = -1;
        %kernel_matrix(:,(d/2-1):d) = 1;
    elseif haar_like_number == 3
        kernel_matrix(c/3+1:2*c/3,:) = -1;
    elseif haar_like_number == 4
        kernel_matrix(:,d/3+1:2*d/3) = -1;
    else 
        kernel_matrix(1:c/2,1:d/2) = -1;
        kernel_matrix(c/2+1:c,d/2+1:d) = -1;
    end    
    for i = a+1:2*a
        for j = b+1:2*b
            count = 0;
            r = 0;
            s = 0;
            % ������
            for p = i:i+c-1
                r = r + 1;
                for q = j:j+d-1
                    s = s + 1;
                    tem = test_m(p,q)*kernel_matrix(r,s);
                    count = count + tem;
                    if s == d
                        s = 0;
                    end    
                end
            end    
            image(i,j) = count;
        end
    end     
        
    
end % if kernel_name 
output_image = image(a+1:2*a,b+1:2*b);
figure(1)
x = imshow(uint8(raw_image));
% figure(2)
% y = imshow(uint8(output_image));
% z = gray2rgb(output_image);
figure(3)
z = imshow(z);

% function [Image]=gray2rgb(Image)
% %Gives a grayscale image an extra dimension
% %in order to use color within it
% [m,n]=size(Image);
% rgb=zeros(m,n,3);
% rgb(:,:,1)=Image;
% rgb(:,:,2)=rgb(:,:,1);
% rgb(:,:,3)=rgb(:,:,1);
% Image=rgb/255;
% end